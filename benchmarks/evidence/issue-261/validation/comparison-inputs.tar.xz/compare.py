import json, pathlib, sys

repo = pathlib.Path('/home/jacek/Projects/rust-reality')
root = pathlib.Path(__file__).parent
base = repo / 'benchmarks/evidence/issue-261'
observations = []
for label, folder, source in (
    ('historical-failed', 'failed', '3b581bdc9d4fbd55fc9e6b02caab67e0d6860949'),
    ('historical-passed', 'passed', '3b581bdc9d4fbd55fc9e6b02caab67e0d6860949'),
    ('pinned-profile', 'pinned-profile/native', 'dbf4773475e7d30a6753f8b90a7db3850cf7f135'),
    ('pinned-control', 'pinned-control/native', 'dbf4773475e7d30a6753f8b90a7db3850cf7f135')):
    directory = base / folder
    summary = json.loads((directory / 'soak-summary.json').read_text())
    rows = [json.loads(line) for line in (directory / 'resources.jsonl').read_text().splitlines()]
    tail = rows[len(rows)//2:]

    def slope(values):
        times = [row['monotonicSeconds'] for row in tail]
        mean_time, mean_value = sum(times)/len(times), sum(values)/len(values)
        return sum((t-mean_time)*(v-mean_value) for t,v in zip(times,values)) / sum(
            (t-mean_time)**2 for t in times) * 3600 / 1024

    aggregate = summary['resourceAggregate']
    calculated = slope([row['vmPssKiB'] for row in tail])
    assert abs(calculated-aggregate['pssTailSlopeMiBPerHour']) < 1e-9
    roles = {}
    for role in rows[0]['processes']:
        identities = {(row['processes'][role]['pid'],row['processes'][role]['pidStarttime']) for row in rows}
        assert len(identities) == 1, (label,role)
        values = [row['processes'][role]['vmPssKiB'] for row in tail]
        roles[role] = dict(pss_tail_slope_mib_per_hour=slope(values), stable_identity=True)
    assert abs(sum(r['pss_tail_slope_mib_per_hour'] for r in roles.values())-calculated) < 1e-9
    observations.append(dict(label=label, source=source, directory=folder,
        product_sha256=summary['binaries']['rustReality']['sha256'],
        native_ok=summary['ok'], resource_samples=len(rows),
        round_observations=sum(row['label'].startswith('round-') for row in rows),
        native_pss_tail_slope_mib_per_hour=aggregate['pssTailSlopeMiBPerHour'],
        recomputed_pss_tail_slope_mib_per_hour=calculated,
        pss_growth_mib=aggregate['pssGrowthMiB'], native_end_seconds=rows[-1]['monotonicSeconds'],
        terminal_completion_present=(
            next(record['soak_completion_present'] for record in
                 json.loads((base/'same-binary.json').read_text())['records']
                 if record['outcome']==('failed' if label.endswith('failed') else 'passed'))
            if label.startswith('historical-') else (directory/'completion.json').exists()),
        roles=roles))

local_processes = {}
for label in ('profile', 'control'):
    directory = root / (label + '-1800')
    execution = json.loads((directory/'execution.json').read_text())
    rows = [json.loads(line) for line in (directory/'smaps.jsonl').read_text().splitlines()]
    rounds = next(r['round_observations'] for r in observations if r['label']=='pinned-'+label)
    roles = {}
    for role in sorted({row['label'] for row in rows}):
        samples = [row for row in rows if row['label']==role]
        assert len({(r['pid'],r['starttime']) for r in samples}) == 1
        first,last = samples[0],samples[-1]
        roles[role] = dict(samples=len(samples), stable_identity=True,
            sampled_cpu_seconds=(last['cpu_ticks']-first['cpu_ticks'])/execution['clock_ticks_per_second'],
            sampled_seconds=last['seconds']-first['seconds'],
            first_pss_kib=first['smaps_kib']['Pss'],last_pss_kib=last['smaps_kib']['Pss'],
            first_anonymous_kib=first['smaps_kib']['Anonymous'],last_anonymous_kib=last['smaps_kib']['Anonymous'],
            thread_range=[min(r['threads'] for r in samples),max(r['threads'] for r in samples)],
            fd_range=[min(r['fds'] for r in samples),max(r['fds'] for r in samples)])
    local_processes[label] = dict(rounds=rounds, roles=roles,
        cpu_scope='First to last two-second process observations. Control includes additional terminal-binding idle time. These are diagnostic observations, not a calibrated performance comparison.')

result = dict(schema='rr-issue261-comparison/v1', root_cause_proven=False,
    product_fix=None, unchanged_pss_tail_limit_mib_per_hour=2.0,
    observations=observations, local_processes=local_processes,
    limits=['One local profile/control pair does not isolate profiling effects from ordinary run variation.',
            'Local glibc 2.43 and 16 workers differ from the historical ubuntu-24.04 workflow and observed thread counts.',
            'Standalone profiled pointer-accounting conflict is rejected; no complete six-process heap attribution.',
            'Neither local run provides 12-hour qualification or an allocation trace of the historical failure.'])
print(json.dumps(result, indent=2))
