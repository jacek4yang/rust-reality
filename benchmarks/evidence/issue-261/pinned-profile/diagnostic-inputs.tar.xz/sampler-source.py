import datetime, hashlib, json, os, pathlib, subprocess, sys, time

output, executable, *command = sys.argv[1:]
out = pathlib.Path(output)
out.mkdir()
started = time.monotonic()
meta = dict(command=command, started=datetime.datetime.now(datetime.timezone.utc).isoformat())
meta['started_monotonic_seconds'] = started
meta['clock_ticks_per_second'] = os.sysconf('SC_CLK_TCK')
meta['harness_sha256'] = hashlib.sha256(pathlib.Path(command[0]).read_bytes()).hexdigest()
meta['binary_inputs'] = {}
for flag in ('--rust-bin', '--xray-bin', '--openssl-bin'):
    binary = pathlib.Path(command[command.index(flag)+1])
    meta['binary_inputs'][flag] = dict(path=str(binary), sha256=hashlib.sha256(binary.read_bytes()).hexdigest())
meta['environment'] = {key: os.environ.get(key) for key in ('RR_261_HEAPTRACK_DIR', 'XDG_RUNTIME_DIR')}
meta['sampler_sha256'] = hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()
(out / 'sampler-source.py').write_bytes(pathlib.Path(__file__).read_bytes())
(out / 'execution.json').write_text(json.dumps(meta, indent=2)+'\n')
with (out/'stdout').open('wb') as stdout, (out/'stderr').open('wb') as stderr, (out/'smaps.jsonl').open('w') as samples:
    child = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True)
    while child.poll() is None:
        for entry in pathlib.Path('/proc').iterdir():
            if not entry.name.isdigit():
                continue
            try:
                if os.readlink(entry/'exe') != executable:
                    continue
                stat = (entry/'stat').read_text().rsplit(')', 1)[1].split()
                if int(stat[1]) != child.pid:
                    continue
                rollup = {}
                for line in (entry/'smaps_rollup').read_text().splitlines()[1:]:
                    key, value, *_ = line.split()
                    rollup[key.rstrip(':')] = int(value)
                status = {k:v.strip() for k,v in (line.split(':',1) for line in (entry/'status').read_text().splitlines())}
                mappings = {}
                bucket = None
                for line in (entry/'smaps').read_text().splitlines():
                    parts=line.split()
                    if '-' in parts[0] and ':' not in parts[0]:
                        name=parts[5] if len(parts)>5 else ''
                        address_start,address_end=[int(x,16) for x in parts[0].split('-')]
                        extent_kib=(address_end-address_start)//1024
                        if name.startswith('/'):
                            bucket='file'
                        elif name:
                            bucket=name
                        else:
                            bucket=f'anonymous-{parts[1]}-{extent_kib}KiB'
                        mappings.setdefault(bucket,{})
                    elif bucket and parts[0].rstrip(':') in ('Rss','Pss','Anonymous','Private_Dirty'):
                        key=parts[0].rstrip(':')
                        mappings[bucket][key]=mappings[bucket].get(key,0)+int(parts[1])
                label = pathlib.Path(os.readlink(entry/'fd/1')).name
                samples.write(json.dumps(dict(seconds=time.monotonic()-started, pid=int(entry.name), starttime=stat[19],
                    label=label, fds=len(list((entry/'fd').iterdir())), threads=int(status['Threads']),
                    cpu_ticks=int(stat[11])+int(stat[12]), smaps_kib=rollup, mappings_kib=mappings))+'\n')
                samples.flush()
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
        time.sleep(2)
    rc=child.wait()
meta.update(ended=datetime.datetime.now(datetime.timezone.utc).isoformat(), exit_code=rc, duration_seconds=time.monotonic()-started)
meta['streams'] = {name:hashlib.sha256((out/name).read_bytes()).hexdigest() for name in ('stdout','stderr','smaps.jsonl')}
(out/'execution.json').write_text(json.dumps(meta, indent=2)+'\n')
print(json.dumps(meta))
sys.exit(rc)
