import datetime, hashlib, json, os, pathlib, subprocess, sys, time

root = pathlib.Path(__file__).parent
profile = root / 'profile-1800'
execution = json.loads((profile / 'execution.json').read_text())
assert 'ended' in execution, 'refuse to analyze an incomplete trace'
output = root / 'profile-analysis'
output.mkdir()
interpreter = '/tmp/rr-261-investigation/heaptrack/usr/lib/heaptrack/libexec/heaptrack_interpret'
printer = '/tmp/rr-261-investigation/heaptrack/usr/bin/heaptrack_print'
environment = dict(os.environ, LD_LIBRARY_PATH='/tmp/rr-261-investigation/heaptrack/usr/lib/x86_64-linux-gnu')
commands = []

def run(name, command, source=None, env=None):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = time.monotonic()
    with (output / name).open('xb') as stdout, (output / (name + '.stderr')).open('xb') as stderr:
        if source:
            with source.open('rb') as stdin:
                result = subprocess.run(command, stdin=stdin, stdout=stdout, stderr=stderr, env=env)
        else:
            result = subprocess.run(command, stdout=stdout, stderr=stderr, env=env)
    receipt = dict(command=command, stdin=str(source) if source else None,
                   started=started, ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   duration_seconds=time.monotonic()-before, exit_code=result.returncode)
    receipt['streams'] = {n: hashlib.file_digest((output / n).open('rb'), 'sha256').hexdigest()
                         for n in (name, name + '.stderr')}
    commands.append(receipt)
    (output / 'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    if result.returncode:
        raise RuntimeError(f'{name}: exit {result.returncode}')

for raw in sorted((root / 'profile-1800-traces').glob('*.raw')):
    role = raw.stem.removeprefix('soak-')
    run(role + '.processed', [interpreter], raw)
    processed = output / (role + '.processed')
    run(role + '.heaptrack.txt', [printer, '--file', str(processed), '--print-leaks=1',
        '--peak-limit', '5', '--sub-peak-limit', '2', '--print-allocators=0', '--print-temporary=0',
        '--disable-builtin-suppressions', '--disable-embedded-suppressions',
        '--print-massif', str(output / (role + '.massif')), '--massif-detailed-freq', '1'], env=environment)
    run(role + '.timeline.json', ['python3', '/tmp/rr-261-investigation/raw_timeline.py', str(raw)])
    run(role + '.owners.json', ['python3', '/tmp/rr-261-investigation/owners-v2.py', str(raw), str(processed)])
    timeline = json.loads((output / (role + '.timeline.json')).read_text())
    owners = json.loads((output / (role + '.owners.json')).read_text())
    assert sum(owners['remaining_bytes'].values()) == timeline['live_bytes']
    print(json.dumps(dict(role=role, live_bytes=timeline['live_bytes'],
        remaining_bytes=owners['remaining_bytes'], seconds=timeline['final_seconds'])), flush=True)
