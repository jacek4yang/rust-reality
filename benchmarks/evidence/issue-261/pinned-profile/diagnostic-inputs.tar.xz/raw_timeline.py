import collections, json, pathlib, sys

for arg in sys.argv[1:]:
    path = pathlib.Path(arg)
    live = {}
    total = 0
    allocations = frees = 0
    trajectory = []
    trace_bytes = collections.Counter()
    seconds = 0
    for line in path.read_text().splitlines():
        parts = line.split()
        if not parts:
            continue
        if parts[0] == '+' and len(parts) == 4:
            size, trace, pointer = [int(x, 16) for x in parts[1:]]
            if pointer in live:
                raise ValueError('reused live pointer')
            live[pointer] = (size, trace)
            total += size
            trace_bytes[trace] += size
            allocations += 1
        elif parts[0] == '-':
            pointer = int(parts[1], 16)
            old = live.pop(pointer, None)
            if old:
                size, trace = old
                total -= size
                trace_bytes[trace] -= size
            frees += 1
        elif parts[0] == 'c':
            seconds = int(parts[1], 16)/1000
            if not trajectory or seconds-trajectory[-1]['seconds'] >= 2:
                trajectory.append(dict(seconds=seconds, live_bytes=total, live_allocations=len(live),
                    allocation_calls=allocations, free_calls=frees,
                    top_live_traces=trace_bytes.most_common(10)))
    print(json.dumps(dict(file=path.name, allocations=allocations, frees=frees,
        final_seconds=seconds, live_bytes=total, live_allocations=len(live), trajectory=trajectory)))
