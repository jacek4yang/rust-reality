import collections, json, pathlib, subprocess, sys

raw_name, interpreted_name = sys.argv[1:]
strings = ['']
ips = [[]]
traces = [('',0)]
for line in pathlib.Path(interpreted_name).read_text().splitlines():
    fields = line.split()
    if not fields:
        continue
    if fields[0] == 's':
        strings.append(line.split(' ',2)[2])
    elif fields[0] == 'i':
        ips.append([int(value,16) for value in fields[3::3]])
    elif fields[0] == 't':
        traces.append((int(fields[1],16),int(fields[2],16)))
decoded = subprocess.check_output(['c++filt','--format=rust'], input=('\n'.join(strings)+'\n').encode()).decode().splitlines()
categories = [
 ('connection_tasks', ('runtime::connection::ConnectionTasks::spawn',)),
 ('warm_pool', ('server::warm_pool::',)),
 ('cover_profiles', ('server::cover_profile::',)),
 ('reality_replay', ('protocol::reality::replay::',)),
 ('handoff_replay', ('HandoffReplayCache',)),
 ('nxr_replay', ('NxrReplayCache',)),
 ('dns', ('server::dns::',)),
 ('buffer_pool', ('tcp_relay::BufferPool',)),
 ('vision', ('server::vision::',)),
 ('configuration', ('config::',)),
 ('signal_registry', ('tokio::signal::',)),
 ('runtime', ('tokio::runtime::',)),
]
trace_owners = {}
for trace in range(1,len(traces)):
    frames=[]
    cursor=trace
    while cursor:
        ip, cursor=traces[cursor]
        frames += [decoded[index] for index in ips[ip]]
    owner='other'
    for category, needles in categories:
        if any(needle in frame for needle in needles for frame in frames):
            owner=category
            break
    trace_owners[trace]=(owner,frames)
live = {}
live_by_owner=collections.Counter()
alloc_bytes=collections.Counter()
free_bytes=collections.Counter()
trajectory=[]
trace_catalog={}
allocation_calls=0
free_calls=0
live_by_trace=collections.Counter()
peak_by_owner=collections.Counter()
seconds=0
for line in pathlib.Path(raw_name).read_text().splitlines():
    fields=line.split()
    if not fields:
        continue
    if fields[0] == '+':
        size,trace,pointer=map(lambda x:int(x,16),fields[1:])
        owner=trace_owners.get(trace,('unresolved',[]))[0]
        live[pointer]=(size,owner,trace)
        live_by_owner[owner]+=size
        alloc_bytes[owner]+=size
        live_by_trace[trace]+=size
        allocation_calls+=1
        peak_by_owner[owner]=max(peak_by_owner[owner],live_by_owner[owner])
    elif fields[0] == '-':
        old=live.pop(int(fields[1],16),None)
        if old:
            size,owner,trace=old
            live_by_owner[owner]-=size
            free_bytes[owner]+=size
            live_by_trace[trace]-=size
        free_calls+=1
    elif fields[0]=='c':
        seconds=int(fields[1],16)/1000
        if not trajectory or seconds-trajectory[-1]['seconds']>=10:
            top=live_by_trace.most_common(10)
            for trace,size in top:
                if trace not in trace_catalog:
                    owner,frames=trace_owners[trace]
                    trace_catalog[trace]=dict(owner=owner,frames=frames)
            trajectory.append(dict(seconds=seconds,live_bytes=dict(live_by_owner),
                allocation_calls=allocation_calls,free_calls=free_calls,
                live_allocation_count=len(live),top_live_traces=top))
remaining=collections.Counter()
for size,owner,trace in live.values():
    remaining[trace]+=size
print(json.dumps(dict(raw=pathlib.Path(raw_name).name, interpreted=pathlib.Path(interpreted_name).name,
      categories=[{'name':n,'backtrace_substrings':list(v)} for n,v in categories],
      peak_bytes=dict(peak_by_owner),trace_catalog=trace_catalog,
      allocated_bytes=dict(alloc_bytes), freed_bytes=dict(free_bytes), remaining_bytes=dict(live_by_owner),
      trajectory=trajectory, remaining_stacks=[dict(bytes=size,trace=trace,owner=trace_owners[trace][0],frames=trace_owners[trace][1]) for trace,size in remaining.most_common(10)])))
