import pathlib,json,hashlib,collections,sys
root=pathlib.Path(__file__).parent;topology=sys.argv[1];d=root/f'{topology}-lifecycle'
expected_image=hashlib.sha256((root/'inputs/rust-reality').read_bytes()).hexdigest()
rows=[json.loads(l) for l in (d/'events.jsonl').read_text().splitlines()];events=[r['event'] for r in rows]
complete=json.loads((d/'complete.json').read_text());assert complete['scope']=='LOCAL_KVM' and complete['elapsed']>=600
transfers=[]
for e in events:
 if e['type'] in ['transfer','readiness']:transfers.append(e['result'])
 if e['type']=='bidirectional':transfers.extend([e['upload'],e['download']])
success=sum(x['ok'] for x in transfers);assert len(transfers)>=500 and success>=450 and success/len(transfers)>=.95
assert all(x['ok'] for x in transfers), 'no failed lifecycle transfer is expected outside the two explicitly killed continuous flows'
assert all(x['integrity'] for x in transfers)
resources={}
for guest in ['line-a','line-b','landing']:
 samples=[e['sample'] for e in events if e['type']=='resource' and e['guest']==guest];assert len(samples)>=12
 first,last=samples[0],samples[-1];identities=sorted({(x['pid'],x['starttime']) for x in samples});assert len(identities)==(2 if guest=='landing' else 1)
 assert len({x['bootId'] for x in samples})==1 and {x['imageSha256'] for x in samples}=={expected_image}
 limits={'fds':(256,1024) if guest=='landing' else (768,2048),'threads':(first['threads']+8,first['threads']+16),'rssKiB':(first['rssKiB']+32768,first['rssKiB']+98304)}
 measurements={}
 for k,(final_limit,peak_limit) in limits.items():
  peak=max(x[k] for x in samples);assert last[k]<=final_limit and peak<=peak_limit,(guest,k,last[k],peak,final_limit,peak_limit)
  measurements[k]={'baseline':first[k],'final':last[k],'peak':peak,'finalLimit':final_limit,'peakLimit':peak_limit}
 resources[guest]={'samples':len(samples),'identities':identities,'bootId':first['bootId'],'imageSha256':first['imageSha256'],'measurements':measurements}
flows={}
for index,guest in enumerate(['line-a','line-b']):
 terminal=json.loads((d/f'continuous-flow-{index}/terminal.json').read_text());received=(d/f'continuous-flow-{index}/received.bin').read_bytes();sent=(d/f'continuous-flow-{index}/sent.bin').read_bytes()
 assert received==sent[:len(received)] and len(received)>0
 assert hashlib.sha256(received).hexdigest()==terminal['receivedSha256'] and hashlib.sha256(sent).hexdigest()==terminal['sentSha256']
 progress=[e for e in events if e['type']=='flow_progress_across_reload' and e['guest']==guest];assert len(progress)==1;p=progress[0]
 raw=(d/f'continuous-flow-{index}.log').read_bytes()
 before=json.loads(raw[:p['logBytesBefore']].splitlines()[-1]);after=json.loads(raw[:p['logBytesAfter']].splitlines()[-1]);assert after['verifiedFrames']>before['verifiedFrames']
 flows[guest]={'terminal':terminal,'verifiedFramesBeforeReload':before['verifiedFrames'],'verifiedFramesAfterReload':after['verifiedFrames'],'receivedPrefixMatchesSent':True}
rejections={};starts={}
kill_start=min(r['unixMs'] for r in rows if r['event']['type']=='resource' and r['event']['label']=='before-landing-kill')
kill_end=next(r['unixMs'] for r in rows if r['event']['type']=='landing_restart')+43000
for guest in resources:
 logs={}
 for f in d.glob(f'{guest}-server-*.log'):
  parsed=[json.loads(l) for l in f.read_text().splitlines() if l.startswith('{')];start=parsed[0]['timestampUnixMs']
  if start not in logs or len(parsed)>len(logs[start]):logs[start]=parsed
 assert len(logs)==(2 if guest=='landing' else 1)
 rejected=[{k:v for k,v in e.items() if k not in ['peer']} for log in logs.values() for e in log if e.get('event')=='connection_rejected']
 assert all(e['reason']=='outbound' and e['failure']['stage'] in ['handoff_relay','nxr_relay'] and e['failure']['cause']=='io' for e in rejected),rejected
 clock=[r for r in rows if r['event']['type']=='resource' and r['event']['guest']==guest]
 offset_min=min(r['event']['sample']['unixMs']-r['unixMs'] for r in clock)
 offset_max=max(r['event']['sample']['unixMs']-r['event']['hostStartedUnixMs'] for r in clock)
 assert all(e['timestampUnixMs']-offset_min>=kill_start and e['timestampUnixMs']-offset_max<=kill_end for e in rejected),rejected
 rejections[guest]=rejected;starts[guest]=sorted(logs)
result={'scope':'LOCAL_KVM','sourceCommit':json.loads((root/'scope.json').read_text())['sourceCommit'],'topology':topology,'complete':complete,'attempts':len(transfers),'successes':success,'successRate':success/len(transfers),'resources':resources,'flows':flows,'serverStartsUnixMs':starts,'controlledKillRejections':rejections,'noAuthenticationOrProtocolRejections':True,'status':'PASS'}
(root/f'{topology}-lifecycle-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
