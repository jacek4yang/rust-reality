import hashlib,json,pathlib,shutil,subprocess,time
base=pathlib.Path('<KVM_CACHE>')
root=base/'established-io-fix-smoke';root.mkdir(mode=0o700);(root/'inputs').mkdir()
source=base/'candidate-583ffed-nxr-v3'
repo=pathlib.Path('<WORKSPACE_ROOT>/rust-reality-phase1')
driver=base/'qualification-20261007/driver/target/release/rr-local-kvm-diagnostic'
for name in ['ssh-config','guests.json','provision-attestation.json']:
 shutil.copyfile(source/name,root/name)
for name in ['rr-dev','xray']:
 shutil.copyfile(source/'inputs'/name,root/'inputs'/name)
shutil.copyfile(repo/'target/debug/rust-reality',root/'inputs/rust-reality')
for path in (root/'inputs').iterdir():path.chmod(0o700)
def run(*args):subprocess.run([str(driver),*map(str,args)],check=True)
def sha(path):return hashlib.file_digest(open(path,'rb'),'sha256').hexdigest()
identity={'scope':'uncommitted-production-fix-debug-smoke-not-frozen-candidate','binarySha256':sha(root/'inputs/rust-reality'),'connectionSourceSha256':sha(repo/'src/server/production/connection.rs'),'driverSha256':sha(driver)}
(root/'identity.json').write_text(json.dumps(identity,indent=2)+'\n')
flows=[]
try:
 run('stage',root,'<CLOSURE_CACHE>/fixed-control-v2','nxr')
 run('smoke',root,'nxr','before-kill')
 guests=json.loads((root/'guests.json').read_text())
 for guest in ['line-a','line-b']:
  out=root/('flow-'+guest)
  stdout=open(root/(guest+'-flow.stdout'),'w');stderr=open(root/(guest+'-flow.stderr'),'w')
  proc=subprocess.Popen([str(driver),'flow',str(guests[guest]['socksPort']),str(out),'30'],stdout=stdout,stderr=stderr)
  flows.append((guest,out,proc,stdout,stderr))
 time.sleep(4)
 for guest,out,proc,_,_ in flows:
  assert proc.poll() is None,(guest,'flow died before controlled fault')
  assert (out/'received.bin').stat().st_size>=40960,(guest,'no established traffic')
 run('restart-probe',root,'nxr')
 for guest,out,proc,stdout,stderr in flows:
  code=proc.wait(timeout=50);stdout.close();stderr.close()
  assert code==1,(guest,code,'controlled LANDING kill must interrupt old flow')
  sent=(out/'sent.bin').read_bytes();received=(out/'received.bin').read_bytes()
  assert len(received)>=40960 and sent.startswith(received),(guest,'corrupted received prefix')
  rows=[]
  for log in (root/'restart-probe').glob(guest+'-server-*.log'):
   for line in log.read_text().splitlines():
    try:rows.append(json.loads(line))
    except json.JSONDecodeError:pass
  rejected=[row for row in rows if row.get('event')=='connection_rejected']
  assert rejected,(guest,'fault did not exercise rejection path')
  assert all(row['reason']=='outbound' and row.get('failure',{}).get('stage')=='session_relay' and row['failure']['cause']=='io' for row in rejected),(guest,rejected)
  identity[guest]={'flowExit':code,'sentBytes':len(sent),'verifiedReceivedPrefixBytes':len(received),'rejections':rejected}
 identity['result']='PASS'
 (root/'result.json').write_text(json.dumps(identity,indent=2)+'\n');print(json.dumps(identity,indent=2))
finally:
 for _,_,proc,stdout,stderr in flows:
  if proc.poll() is None:proc.terminate();proc.wait(timeout=10)
  stdout.close();stderr.close()
 run('stop',root,'nxr')
