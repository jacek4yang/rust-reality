import pathlib,json,hashlib,tarfile,subprocess
r=pathlib.Path(__file__).parent;aid=11466936938;d=r/str(aid)
meta=json.loads((r/f'{aid}.json').read_text());scope=json.loads((d/'candidate-scope.json').read_text());tier=json.loads((d/'linux-aarch64-generic.tier.json').read_text())
sha='583ffed78f3a943b8a2235d158060a537ec284b2'
assert scope['sourceCommit']==tier['commit']==meta['workflow_run']['head_sha']==sha
assert scope['releaseTagCreated'] is False and tier['measuredNatively'] is True
archive=d/tier['artifact'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==tier['sha256']
out=d/'unpacked';out.mkdir(exist_ok=True);assert not any(out.iterdir())
with tarfile.open(archive) as t:
 members=[m for m in t if pathlib.PurePosixPath(m.name)==pathlib.PurePosixPath('rust-reality')];assert len(members)==1
 member=members[0];assert member.isfile();t.extract(member,out,filter='data')
binary=out/'rust-reality';data=binary.read_bytes();assert data[:6]==b'\x7fELF\x02\x01' and int.from_bytes(data[18:20],'little')==183
identity=subprocess.check_output(['readelf','-h','-n',str(binary)],text=True)
result={'scope':scope,'artifact':meta,'tier':tier,'binarySha256':hashlib.sha256(data).hexdigest(),'elfIdentity':identity,'nativeCompiler':(d/'compiler.txt').read_text(),'nativeKernel':(d/'kernel.txt').read_text(),'nativeLibc':(d/'libc.txt').read_text(),'workflowRun':37586749887,'job':112678537008,'localExecution':False,'status':'verified-package-and-source-bindings; native-execution-receipt-is-Actions-job'}
(r/'arm-candidate-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'commit':sha,'packageSha256':tier['sha256'],'binarySha256':result['binarySha256'],'nativeLibc':result['nativeLibc']}))
