use std::{env,fs,io::{Read,Write},net::{TcpListener,TcpStream},path::{Path,PathBuf},process::Command,sync::{Arc,atomic::{AtomicBool,AtomicU64,Ordering}},thread,time::{Duration,Instant}};
use serde_json::{Value,json};
use sha2::{Digest,Sha256};
use parking_lot::Mutex;
type Result<T, E = Box<dyn std::error::Error + Send + Sync>> = std::result::Result<T,E>;
fn unix_ms()->Result<u128> {Ok(std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)?.as_millis())}
fn hash_file(path:impl AsRef<Path>)->Result<(u64,String)> {
 let mut file=fs::File::open(path)?;let mut hash=Sha256::new();let mut bytes=0;let mut buffer=[0;65536];
 loop {let n=file.read(&mut buffer)?;if n==0{break;}hash.update(&buffer[..n]);bytes+=n as u64;}
 Ok((bytes,format!("{:x}",hash.finalize())))
}
fn payload(path:impl AsRef<Path>)->Result<()> {
 let mut file=fs::File::create(path)?;let mut buffer=[0;4096];
 for (i,b) in buffer.iter_mut().enumerate(){*b=(i%256) as u8;}
 for _ in 0..256{file.write_all(&buffer)?;}Ok(())
}
fn load(path:impl AsRef<Path>)->Result<Value>{Ok(serde_json::from_slice(&fs::read(path)?)?)}
fn save(path:impl AsRef<Path>,v:&Value)->Result<()> {fs::write(path,serde_json::to_vec_pretty(v)?)?;Ok(())}
fn output(mut command:Command)->Result<String>{let o=command.output()?;if !o.status.success(){return Err(format!("command failed {}: {}",o.status,String::from_utf8_lossy(&o.stderr)).into());}Ok(String::from_utf8(o.stdout)?)}
fn ssh(root:&Path,guest:&str,command:&str)->Result<String>{let mut c=Command::new("ssh");c.args(["-F"]).arg(root.join("ssh-config")).args([guest,command]);output(c)}
fn scp(root:&Path,guest:&str,local:&Path,remote:&str)->Result<()> {let mut c=Command::new("scp");c.arg("-F").arg(root.join("ssh-config")).arg(local).arg(format!("{guest}:{remote}"));output(c)?;Ok(())}
fn remote_start(root:&Path,guest:&str,dir:&str,label:&str,argv:&str)->Result<()> {
 ssh(root,guest,&format!("cd {dir} && (nohup env -i PATH=/usr/bin:/bin SSL_CERT_FILE={dir}/origin-ca.pem {argv} </dev/null >{label}.log 2>&1 & echo $! >{label}.pid)"))?;Ok(())
}
fn sample(dir:&str)->Result<Value>{
 let pid=fs::read_to_string(format!("{dir}/server.pid"))?.trim().parse::<u32>()?;
 let stat=fs::read_to_string(format!("/proc/{pid}/stat"))?;let start=stat.rsplit_once(')').ok_or("bad stat")?.1.split_whitespace().nth(19).ok_or("no starttime")?.to_owned();
 let status=fs::read_to_string(format!("/proc/{pid}/status"))?;
 let field=|key:&str|->Result<u64>{Ok(status.lines().find_map(|l| l.strip_prefix(key)).ok_or("missing status field")?.split_whitespace().next().ok_or("empty field")?.parse()?)};
 let smaps=fs::read_to_string(format!("/proc/{pid}/smaps_rollup"))?;
 let mem=|key:&str|->Result<u64>{Ok(smaps.lines().find_map(|l|l.strip_prefix(key)).ok_or("missing smaps field")?.split_whitespace().next().ok_or("empty memory field")?.parse()?)};
 let mut fds=Vec::new();for e in fs::read_dir(format!("/proc/{pid}/fd"))? {let e=e?;fds.push(fs::read_link(e.path())?.display().to_string());}
 let (_,image_hash)=hash_file(format!("/proc/{pid}/exe"))?;
 Ok(json!({"unixMs":unix_ms()?,"pid":pid,"starttime":start,"bootId":fs::read_to_string("/proc/sys/kernel/random/boot_id")?.trim(),"imageSha256":image_hash,"rssKiB":field("VmRSS:")?,"threads":field("Threads:")?,"pssKiB":mem("Pss:")?,"anonymousKiB":mem("Anonymous:")?,"privateDirtyKiB":mem("Private_Dirty:")?,"fds":fds.len(),"fdTargets":fds}))
}
fn socks(port:u16,target:u16)->Result<TcpStream>{
 let mut s=TcpStream::connect(("127.0.0.1",port))?;s.set_read_timeout(Some(Duration::from_secs(45)))?;s.set_write_timeout(Some(Duration::from_secs(45)))?;
 s.write_all(&[5,1,0])?;let mut reply=[0;2];s.read_exact(&mut reply)?;if reply!=[5,0]{return Err("SOCKS authentication response".into());}
 let [hi,lo]=target.to_be_bytes();s.write_all(&[5,1,0,1,127,0,0,1,hi,lo])?;
 let mut h=[0;4];s.read_exact(&mut h)?;if h[1]!=0{return Err(format!("SOCKS connect code {}",h[1]).into());}
 let n=match h[3]{1=>6,4=>18,3=>{let mut n=[0];s.read_exact(&mut n)?;usize::from(n[0])+2},_=>return Err("bad SOCKS address".into())};let mut rest=vec![0;n];s.read_exact(&mut rest)?;Ok(s)
}
fn echo()->Result<()> {for c in TcpListener::bind("127.0.0.1:8082")?.incoming(){let mut s=c?;thread::spawn(move||{let mut buf=[0;16384];while let Ok(n)=s.read(&mut buf){if n==0||s.write_all(&buf[..n]).is_err(){break;}}});}Ok(())}
fn flow(port:u16,out:&Path,seconds:u64)->Result<()> {
 fs::create_dir(out)?;let mut s=socks(port,8082)?;let mut r=s.try_clone()?;let stopped=Arc::new(AtomicBool::new(false));let done=stopped.clone();
 let rx=out.join("received.bin");let reader=thread::spawn(move||->Result<u64>{let mut f=fs::File::create(rx)?;let mut frame=[0;4096];let mut index=0_u64;loop{match r.read_exact(&mut frame){Ok(())=>{},Err(e)=>{done.store(true,Ordering::Relaxed);return Err(format!("flow terminated after {index} verified frames: {e}").into());}}
 for (j,b) in frame.iter().enumerate(){if *b!=((index+j as u64)%251) as u8{return Err("FLOW INTEGRITY CORRUPTION".into());}}
 f.write_all(&frame)?;index+=1;if index%10==0{println!("{}",json!({"verifiedFrames":index,"bytes":index*4096}));}
 }});
 let start=Instant::now();let mut f=fs::File::create(out.join("sent.bin"))?;let mut index=0_u64;let mut write_error=None;
 while start.elapsed()<Duration::from_secs(seconds)&&!stopped.load(Ordering::Relaxed){let mut frame=[0;4096];for(j,b)in frame.iter_mut().enumerate(){*b=((index+j as u64)%251) as u8;}if let Err(e)=s.write_all(&frame){write_error=Some(e.to_string());break;}f.write_all(&frame)?;index+=1;thread::sleep(Duration::from_millis(100));}
 let _=s.shutdown(std::net::Shutdown::Write);let read_result=reader.join().map_err(|_|"reader panic")?;
 let (sent_bytes,sent_hash)=hash_file(out.join("sent.bin"))?;let (received_bytes,received_hash)=hash_file(out.join("received.bin"))?;
 save(out.join("terminal.json"),&json!({"sentBytes":sent_bytes,"receivedBytes":received_bytes,"sentSha256":sent_hash,"receivedSha256":received_hash,"writeError":write_error,"readResult":format!("{read_result:?}"),"elapsed":start.elapsed().as_secs_f64()}))?;
 if sent_bytes!=received_bytes||sent_hash!=received_hash||start.elapsed()<Duration::from_secs(seconds){return Err("flow interrupted; terminal byte counts retained".into());}Ok(())
}
fn guest_dir(topology:&str)->String {format!("/home/rrtest/qualification/candidate-583ffed/{topology}")}
fn stage(root:&Path,fixture:&Path,topology:&str)->Result<()> {
 if !["handoff","nxr"].contains(&topology){return Err("unsupported topology".into());}
 let local=root.join(format!("configs-{topology}"));fs::create_dir(&local)?;
 let dir=guest_dir(topology);let binary=root.join("inputs/rust-reality");let tools=root.join("inputs/rr-dev");let driver=env::current_exe()?;
 for guest in ["landing","line-a","line-b"] {
  ssh(root,guest,&format!("mkdir -p {dir}/assets /home/rrtest/bin"))?;
  for (path,name) in [(&binary,"rust-reality"),(&tools,"rr-dev"),(&root.join("inputs/xray"),"xray"),(&driver,"vm-driver")] {scp(root,guest,path,&format!("/home/rrtest/bin/{name}"))?;}
  for name in ["origin-cert.pem","origin-key.pem","origin-ca.pem","payload-4.bin"]{scp(root,guest,&fixture.join(name),&format!("{dir}/{name}"))?;}
  ssh(root,guest,"chmod 700 /home/rrtest/bin/*")?;
 }
 payload(local.join("payload-1.bin"))?;scp(root,"landing",&local.join("payload-1.bin"),&format!("{dir}/payload-1.bin"))?;
 let mut landing=load(fixture.join(if topology=="handoff"{"landing.json"}else{"nxr-landing.json"}))?;
 landing["listeners"][0]["ipv4"]=json!("0.0.0.0");landing["listeners"][0]["port"]=json!(9443);
 save(local.join("landing.json"),&landing)?;scp(root,"landing",&local.join("landing.json"),&format!("{dir}/server.json"))?;
 for (guest,ip) in [("line-a","192.0.2.2"),("line-b","192.0.2.6")] {
  let mut line=load(fixture.join(if topology=="handoff"{"line.json"}else{"nxr-line.json"}))?;
  line["listeners"][0]["port"]=json!(9444);line["assets"]["cacheDirectory"]=json!(format!("{dir}/assets"));line["reality"]["cover"]=json!(format!("{ip}:8443"));line["outbounds"]["landing-1"]["address"]=json!(ip);line["outbounds"]["landing-1"]["port"]=json!(9443);
  save(local.join(format!("{guest}.json")),&line)?;scp(root,guest,&local.join(format!("{guest}.json")),&format!("{dir}/server.json"))?;
  let mut client=load(fixture.join(format!("{topology}-client.json")))?;client["inbounds"][0]["port"]=json!(1080);client["inbounds"][0]["listen"]=json!("0.0.0.0");client["outbounds"][0]["settings"]["vnext"][0]["address"]=json!("127.0.0.1");client["outbounds"][0]["settings"]["vnext"][0]["port"]=json!(9444);
  save(local.join(format!("{guest}-client.json")),&client)?;scp(root,guest,&local.join(format!("{guest}-client.json")),&format!("{dir}/client.json"))?;
 }
 for guest in ["landing","line-a","line-b"] {let receipt=ssh(root,guest,&format!("/home/rrtest/bin/rust-reality check --config {dir}/server.json && /home/rrtest/bin/rust-reality --version && sha256sum /home/rrtest/bin/* && /home/rrtest/bin/rust-reality explain --config {dir}/server.json --json"))?;fs::write(local.join(format!("{guest}-identity.txt")),receipt)?;}
 remote_start(root,"landing",&dir,"origin",&format!("/home/rrtest/bin/rr-dev bench origin --listen-address 127.0.0.1 --port 8080 --payload-dir {dir} --put-log {dir}/puts.jsonl --access-log {dir}/access.jsonl --label local-kvm-origin"))?;
 remote_start(root,"landing",&dir,"cover",&format!("/home/rrtest/bin/rr-dev bench origin --listen-address 0.0.0.0 --port 8443 --payload-dir {dir} --put-log {dir}/cover-puts.jsonl --tls-cert {dir}/origin-cert.pem --tls-key {dir}/origin-key.pem"))?;
 remote_start(root,"landing",&dir,"echo","/home/rrtest/bin/vm-driver echo")?;
 remote_start(root,"landing",&dir,"server",&format!("/home/rrtest/bin/rust-reality run --config {dir}/server.json"))?;
 for guest in ["line-a","line-b"] {remote_start(root,guest,&dir,"server",&format!("/home/rrtest/bin/rust-reality run --config {dir}/server.json"))?;remote_start(root,guest,&dir,"client",&format!("/home/rrtest/bin/xray run -config {dir}/client.json"))?;}
 Ok(())
}
fn transfer(port:u16,out:&Path,id:u64,upload:bool)->Result<Value>{
 let path=out.join(format!("transfer-{id}.bin"));let start=Instant::now();let mut c=Command::new("curl");c.env_clear().env("PATH","/usr/bin:/bin").args(["--fail","--silent","--show-error","--max-time","43","--noproxy","","--socks5-hostname"]).arg(format!("127.0.0.1:{port}"));
 if upload {c.arg("--upload-file").arg(out.join("payload-1.bin")).arg(format!("http://127.0.0.1:8080/upload/{}/{id}",out.file_name().ok_or("output label")?.to_str().ok_or("output label encoding")?)).arg("--output").arg(&path);}else{c.arg("http://127.0.0.1:8080/payload-1.bin").arg("--output").arg(&path);}
 let result=c.output()?;let observed=hash_file(&path);let file_error=observed.as_ref().err().map(ToString::to_string);let (bytes,digest)=observed.unwrap_or((0,String::new()));let integrity=upload||digest=="fbbab289f7f94b25736c58be46a994c441fd02552cc6022352e3d86d2fab7c83";
 let ok=result.status.success()&&integrity;if ok {fs::remove_file(&path)?;}
 Ok(json!({"id":id,"port":port,"upload":upload,"ok":ok,"integrity":integrity,"bytes":bytes,"sha256":digest,"fileError":file_error,"seconds":start.elapsed().as_secs_f64(),"code":result.status.code(),"stderr":String::from_utf8_lossy(&result.stderr)}))
}
struct Harness {root:PathBuf,out:PathBuf,dir:String,ports:[u16;2],start:Instant,next:AtomicU64,records:Mutex<fs::File>}
impl Harness {
 fn new(root:&Path,topology:&str,label:&str)->Result<Self>{let out=root.join(label);fs::create_dir(&out)?;payload(out.join("payload-1.bin"))?;let specs=load(root.join("guests.json"))?;Ok(Self{root:root.into(),records:Mutex::new(fs::File::create(out.join("events.jsonl"))?),out,dir:guest_dir(topology),ports:[specs["line-a"]["socksPort"].as_u64().ok_or("port")? as u16,specs["line-b"]["socksPort"].as_u64().ok_or("port")? as u16],start:Instant::now(),next:AtomicU64::new(0)})}
 fn record(&self,v:Value)->Result<()> {let v=json!({"elapsed":self.start.elapsed().as_secs_f64(),"unixMs":unix_ms()?,"event":v});let mut f=self.records.lock();writeln!(f,"{v}")?;f.flush()?;Ok(())}
 fn samples(&self,label:&str)->Result<()> {for guest in ["line-a","line-b","landing"]{let before=unix_ms()?;let text=ssh(&self.root,guest,&format!("/home/rrtest/bin/vm-driver sample {}",self.dir))?;let sample:Value=serde_json::from_str(&text)?;self.record(json!({"type":"resource","label":label,"guest":guest,"hostStartedUnixMs":before,"sample":sample}))?;}Ok(())}
 fn batch(&self,n:u64,concurrency:u64,label:&str,allow_failures:bool)->Result<()> {let count=AtomicU64::new(0);let failed=AtomicU64::new(0);thread::scope(|scope|->Result<()>{let jobs=(0..concurrency).map(|worker|{let count=&count;let failed=&failed;scope.spawn(move||->Result<()>{loop{let index=count.fetch_add(1,Ordering::Relaxed);if index>=n{break;}let id=self.next.fetch_add(1,Ordering::Relaxed);let v=transfer(self.ports[(worker%2)as usize],&self.out,id,false)?;if v["ok"]!=true{failed.fetch_add(1,Ordering::Relaxed);}self.record(json!({"type":"transfer","label":label,"result":v}))?;}Ok(())})}).collect::<Vec<_>>();for j in jobs{j.join().map_err(|_|"batch panic")??;}Ok(())})?;if failed.load(Ordering::Relaxed)>0&&!allow_failures{return Err(format!("{label}: {} failures",failed.load(Ordering::Relaxed)).into());}Ok(())}
 fn ready(&self)->Result<()> {let started=Instant::now();loop{let mut ok=true;for port in self.ports{let id=self.next.fetch_add(1,Ordering::Relaxed);let v=transfer(port,&self.out,id,false)?;ok &= v["ok"]==true;self.record(json!({"type":"readiness","result":v}))?;}if ok{return Ok(());}if started.elapsed()>Duration::from_secs(43){return Err("readiness beyond configured deadlines plus fixture bound".into());}thread::sleep(Duration::from_millis(100));}}
 fn reload(&self,guest:&str)->Result<()> {ssh(&self.root,guest,&format!("kill -HUP $(cat {}/server.pid)",self.dir))?;let t=Instant::now();loop{let log=ssh(&self.root,guest,&format!("cat {}/server.log",self.dir))?;if log.lines().filter_map(|l|serde_json::from_str::<Value>(l).ok()).any(|v|v["event"]=="configuration_published"&&v["generation"]==1){break;}if t.elapsed()>Duration::from_secs(20){return Err("reload generation not published".into());}thread::sleep(Duration::from_millis(100));}self.record(json!({"type":"reload","guest":guest,"generation":1}))}
 fn restart(&self)->Result<()> {self.samples("before-landing-kill")?;self.logs()?;ssh(&self.root,"landing",&format!("kill -KILL $(cat {}/server.pid)",self.dir))?;remote_start(&self.root,"landing",&self.dir,"server",&format!("/home/rrtest/bin/rust-reality run --config {}/server.json",self.dir))?;self.record(json!({"type":"landing_restart"}))?;self.ready()}
 fn logs(&self)->Result<()> {for guest in ["line-a","line-b","landing"]{for label in if guest=="landing"{vec!["server","origin","cover"]}else{vec!["server","client"]}{let text=ssh(&self.root,guest,&format!("cat {}/{label}.log",self.dir))?;fs::write(self.out.join(format!("{guest}-{label}-{}.log",self.start.elapsed().as_millis())),text)?;}}Ok(())}
 fn integrity(&self)->Result<()> {
  let mut uploads=Vec::new();
  for port in self.ports {
   let upload_id=self.next.fetch_add(1,Ordering::Relaxed);
   let download_id=self.next.fetch_add(1,Ordering::Relaxed);
   let (u,d)=thread::scope(|s|{
    let u=s.spawn(||transfer(port,&self.out,upload_id,true));
    let d=s.spawn(||transfer(port,&self.out,download_id,false));
    (u.join().unwrap(),d.join().unwrap())
   });
   let u=u?;let d=d?;
   self.record(json!({"type":"bidirectional","upload":u,"download":d}))?;
   if u["ok"]!=true||d["ok"]!=true{return Err("bidirectional transfer failed".into());}
   uploads.push(upload_id);
  }
  let text=ssh(&self.root,"landing",&format!("cat {}/access.jsonl",self.dir))?;
  fs::write(self.out.join("upload-receipts.jsonl"),&text)?;
  for id in uploads {
   let expected_path=format!("/upload/{}/{id}",self.out.file_name().ok_or("output label")?.to_str().ok_or("output label encoding")?);
   let matches=text.lines().filter_map(|l|serde_json::from_str::<Value>(l).ok()).filter(|v|v["path"]==expected_path&&v["bytes"]==1048576&&v["sha256"]=="fbbab289f7f94b25736c58be46a994c441fd02552cc6022352e3d86d2fab7c83").count();
   if matches!=1{return Err(format!("upload {id} has {matches} matching integrity receipts").into());}
  }
  Ok(())
 }
}
struct OwnedChild(std::process::Child);
impl Drop for OwnedChild {
 fn drop(&mut self) {let _=self.0.kill();let _=self.0.wait();}
}
fn lifecycle(root:&Path,topology:&str)->Result<()> {
 let h=Harness::new(root,topology,&format!("{topology}-lifecycle"))?;h.ready()?;h.samples("baseline")?;
 let mut flows=Vec::new();
 for (i,port) in h.ports.iter().enumerate() {
  let log=fs::File::create(h.out.join(format!("continuous-flow-{i}.log")))?;
  flows.push(OwnedChild(Command::new(env::current_exe()?).args(["flow",&port.to_string()]).arg(h.out.join(format!("continuous-flow-{i}"))).arg("650").stdout(log.try_clone()?).stderr(log).spawn()?));
 }
 let points=[0,45,135,210,270,330,390,450,540,570,600];
 let specs=[("warmup",4,16),("steady",8,32),("churn",32,96),("burst",32,96),("quiet-retirement",0,0),("post-line-reload",8,32),("post-landing-restart",16,64),("integrity-recovery",16,64),("final-steady",8,32),("quiet-recovery",0,0)];
 let mut next_sample=Instant::now();let begun=Instant::now();
 for (i,(name,concurrency,n)) in specs.into_iter().enumerate(){
  if i==5 {
   for (index,guest) in ["line-a","line-b"].into_iter().enumerate() {
    let path=h.out.join(format!("continuous-flow-{index}.log"));
    let before=fs::metadata(&path)?.len();h.reload(guest)?;
    thread::sleep(Duration::from_secs(2));
    let after=fs::metadata(&path)?.len();
    if flows[index].0.try_wait()?.is_some()||after<=before{return Err(format!("{guest}: continuous flow stopped progressing across reload").into());}
    h.record(json!({"type":"flow_progress_across_reload","guest":guest,"logBytesBefore":before,"logBytesAfter":after}))?;
   }
  }
  if i==6 {
   h.logs()?;h.restart()?;
   for (index,flow) in flows.iter_mut().enumerate(){
    let result=flow.0.wait()?;h.record(json!({"type":"controlled_flow_termination","line":index,"status":result.code()}))?;
   }
  }
  if i==7 {h.integrity()?;}
  h.record(json!({"type":"phase","name":name,"concurrency":concurrency,"batch":n}))?;
  while begun.elapsed()<Duration::from_secs(points[i+1]){
   if concurrency>0{h.batch(n,concurrency,name,i==6)?;}else{thread::sleep(Duration::from_millis(200));}
   if Instant::now()>=next_sample {h.samples(name)?;next_sample=Instant::now()+Duration::from_secs(10);}
  }
 }
 h.samples("final")?;h.logs()?;
 save(h.out.join("complete.json"),&json!({"scope":"LOCAL_KVM","scheduleSeconds":600,"elapsed":begun.elapsed().as_secs_f64(),"attempts":h.next.load(Ordering::Relaxed)}))?;Ok(())
}
fn shape(root:&Path,link:usize,delay:Option<u64>,loss:u32)->Result<()> {
 let line=if link==0{"line-a"}else{"line-b"};
 for (guest,iface) in [(line,"data0".to_owned()),("landing",format!("data{link}"))] {
  let command=match delay {Some(ms)=>format!("sudo tc qdisc replace dev {iface} root netem delay {ms}ms loss random {loss}%"),None=>format!("sudo tc qdisc del dev {iface} root")};
  ssh(root,guest,&command)?;
 }
 Ok(())
}
fn faults(root:&Path,topology:&str)->Result<()> {
 let h=Harness::new(root,topology,&format!("{topology}-faults"))?;h.ready()?;h.samples("baseline")?;h.batch(100,4,"no-fault",false)?;
 for (rtt,loss) in [(50,0),(100,0),(200,0),(100,1)] {
  for link in 0..2{shape(root,link,Some(rtt/2),loss)?;}
  for (guest,ip) in [("line-a","192.0.2.2"),("line-b","192.0.2.6")] {
   let ping=ssh(root,guest,&format!("ping -c 3 {ip}"))?;h.record(json!({"type":"rtt","guest":guest,"addedRttMs":rtt,"lossPerEgressPercent":loss,"ping":ping}))?;
  }
  let result=h.batch(100,4,&format!("rtt-{rtt}-loss-{loss}"),false);
  for link in 0..2{shape(root,link,None,0)?;}
  result?;let restored=Instant::now();h.ready()?;h.batch(100,4,"100-consecutive-after-netem",false)?;h.record(json!({"type":"recovery","seconds":restored.elapsed().as_secs_f64()}))?;h.samples("after-netem")?;
 }
 let log=fs::File::create(h.out.join("unaffected-flow.log"))?;
 let mut flow=OwnedChild(Command::new(env::current_exe()?).args(["flow",&h.ports[1].to_string()]).arg(h.out.join("unaffected-flow")).arg("30").stdout(log.try_clone()?).stderr(log).spawn()?);
 thread::sleep(Duration::from_secs(2));
 shape(root,0,Some(0),100)?;h.record(json!({"type":"partition-start","link":"line-a","seconds":10}))?;
 thread::scope(|s|->Result<()> {
  let traffic=s.spawn(||h.batch(20,4,"partition-counted-outcomes",true));
  thread::sleep(Duration::from_secs(10));shape(root,0,None,0)?;h.record(json!({"type":"partition-restored"}))?;
  if flow.0.try_wait()?.is_some(){return Err("unaffected LINE-B flow terminated during LINE-A partition".into());}
  traffic.join().map_err(|_|"partition worker panic")??;Ok(())
 })?;
 h.ready()?;h.batch(100,4,"100-consecutive-after-partition",false)?;h.samples("after-partition")?;
 if !flow.0.wait()?.success(){return Err("unaffected flow integrity failed".into());}
 h.restart()?;h.batch(100,4,"100-consecutive-after-kill",false)?;h.integrity()?;
 for i in 0..18{thread::sleep(Duration::from_secs(10));h.samples(&format!("quiet-{i}"))?;}
 h.logs()?;save(h.out.join("complete.json"),&json!({"scope":"LOCAL_KVM","cells":["baseline","rtt50","rtt100","rtt200","rtt100-loss1","line-a-partition10","landing-kill-restart"]}))?;Ok(())
}
fn stop(root:&Path,topology:&str)->Result<()> {let dir=guest_dir(topology);for guest in ["line-a","line-b","landing"]{ssh(root,guest,&format!("for p in {dir}/*.pid; do test ! -f \"$p\" || kill -TERM $(cat \"$p\") 2>/dev/null || true; done"))?;}Ok(())}
fn main()->Result<()> {
 let a=env::args().collect::<Vec<_>>();
 match a.get(1).map(String::as_str){
  Some("echo")=>echo(),
  Some("sample")=>{println!("{}",sample(&a[2])?);Ok(())},
  Some("flow")=>flow(a[2].parse()?,Path::new(&a[3]),a[4].parse()?),
  Some("stage")=>stage(Path::new(&a[2]),Path::new(&a[3]),&a[4]),
  Some("lifecycle")=>lifecycle(Path::new(&a[2]),&a[3]),
  Some("faults")=>faults(Path::new(&a[2]),&a[3]),
  Some("stop")=>stop(Path::new(&a[2]),&a[3]),
  Some("smoke")=>{
   let h=Harness::new(Path::new(&a[2]),&a[3],a.get(4).map(String::as_str).unwrap_or(&format!("{}-smoke",a[3])))?;
   h.ready()?;h.batch(100,4,"smoke",false)?;h.integrity()?;h.samples("smoke")?;h.logs()
  },
  _=>Err("expected echo/sample/flow/stage/lifecycle/faults/stop/smoke".into())
 }
}
