import hashlib,json,os,pathlib,shutil,subprocess
closure=pathlib.Path(__file__).parent;base=pathlib.Path('/home/jacek/.cache/rr-phase1-kvm/candidate-1da34e3');driver=base.parent/'qualification-20261007/driver/target/release/rr-local-kvm-diagnostic';out=base.parent/'candidate-packages-1da34e3';out.mkdir(mode=0o700);results=[]
def run(*args):subprocess.run([str(value) for value in args],check=True)
for tier in ['linux-x86_64-generic','linux-x86_64-musl','linux-x86_64-v3']:
 root=out/tier;root.mkdir();(root/'inputs').mkdir();binary=closure/'candidate-unpacked-1da34e3'/tier/'rust-reality';digest=hashlib.file_digest(open(binary,'rb'),'sha256').hexdigest()
 for name in ['ssh-config','guests.json','large-integrity.py']:shutil.copyfile(base/name,root/name)
 for name in ['rr-dev','xray']:os.link(base/'inputs'/name,root/'inputs'/name)
 shutil.copyfile(binary,root/'inputs/rust-reality');(root/'inputs/rust-reality').chmod(0o700)
 (root/'scope.json').write_text(json.dumps({'scope':'LOCAL_KVM_PACKAGE_SMOKE','sourceCommit':'1da34e37a2b38a774eb3fc14764c108356606963','tier':tier,'elfSha256':digest,'releasePublished':False},indent=2)+'\n')
 for topology in ['handoff','nxr']:
  run(driver,'stage',root,closure/'fixed-control-v2',topology)
  try:
   run(driver,'smoke',root,topology);run('python3',root/'large-integrity.py',topology,topology+'-large',closure/'fixed-control-v2/payload-4.bin')
   data=root/(topology+'-smoke');events=[json.loads(line)['event'] for line in (data/'events.jsonl').read_text().splitlines()];attempts=[]
   for event in events:
    if event['type'] in ['transfer','readiness']:attempts.append(event['result'])
    elif event['type']=='bidirectional':attempts.extend([event['upload'],event['download']])
    elif event['type']=='resource':assert event['sample']['imageSha256']==digest
   assert sum(e['type']=='transfer' for e in events)==100
   assert all(a['ok'] and a['integrity'] and a['code']==0 for a in attempts)
   for path in data.glob('*-server-*.log'):
    records=[json.loads(line) for line in path.read_text().splitlines() if line.strip()];assert records and all(r.get('level') in ['debug','info','warn'] and r.get('event')!='connection_rejected' for r in records)
   result={'tier':tier,'topology':topology,'elfSha256':digest,'verifiedAttempts':len(attempts),'largeIntegrity':json.loads((root/(topology+'-large')/'complete.json').read_text()),'status':'PASS'};results.append(result)
   (root/(topology+'-package-audit.json')).write_text(json.dumps(result,indent=2)+'\n')
  finally:run(driver,'stop',root,topology)
(out/'complete.json').write_text(json.dumps({'scope':'LOCAL_KVM_PACKAGE_SMOKE','results':results,'status':'PASS'},indent=2)+'\n');print(json.dumps({'status':'PASS','cells':len(results)}))
