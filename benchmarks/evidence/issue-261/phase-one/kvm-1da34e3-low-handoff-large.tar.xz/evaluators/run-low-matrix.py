import hashlib,json,pathlib,shutil,subprocess
root=pathlib.Path('/home/jacek/.cache/rr-phase1-kvm/candidate-1da34e3-low');closure=pathlib.Path(__file__).parent;driver=root.parent/'qualification-20261007/driver/target/release/rr-local-kvm-diagnostic';results=[]
def run(*args):subprocess.run([str(value) for value in args],check=True)
for topology in ['handoff','nxr']:
 run(driver,'stage',root,closure/'fixed-control-v2',topology)
 try:
  run(driver,'smoke',root,topology);run(driver,'stress',root,topology);run('python3',root/'audit-stress.py',topology)
  recovery=root/(topology+'-recovery');recovery.mkdir()
  for name in ['ssh-config','guests.json']:shutil.copyfile(root/name,recovery/name)
  run(driver,'restart-probe',recovery,topology);data=recovery/'restart-probe';raw=[json.loads(line) for line in (data/'events.jsonl').read_text().splitlines()];rows=[row['event'] for row in raw];attempts=[e['result'] for e in rows if e['type']=='transfer']
  assert len(attempts)==100 and all(a['ok'] and a['integrity'] and a['code']==0 and a['seconds']<=43 for a in attempts)
  kill=next(row for row in raw if row['event']['type']=='landing_restart');first=next(row for row in raw if row['event']['type']=='readiness' and row['event']['result']['ok']);recovery_seconds=first['elapsed']-kill['elapsed'];assert 0<=recovery_seconds<=43
  kill_start=min(row['unixMs'] for row in raw if row['event']['type']=='resource' and row['event']['label']=='before-landing-kill');kill_end=kill['unixMs']+43000;rejections={}
  for guest in ['line-a','line-b','landing']:
   samples=[e['sample'] for e in rows if e['type']=='resource' and e['guest']==guest];assert samples
   final=samples[-1];assert {sample['imageSha256'] for sample in samples}=={'47bd2151d9348562ec547c0867f3cbd9b72d35b28255cce8e7fd240f30deec9a'}
   limits={'fds':(256,1024) if guest=='landing' else (768,2048),'threads':(samples[0]['threads']+8,samples[0]['threads']+16),'rssKiB':(samples[0]['rssKiB']+32768,samples[0]['rssKiB']+98304)}
   for field,(end,peak) in limits.items():assert final[field]<=end and max(sample[field] for sample in samples)<=peak,(guest,field)
   identities={(sample['pid'],sample['starttime']) for sample in samples};assert len(identities)==(2 if guest=='landing' else 1)
   records={}
   for path in data.glob(guest+'-server-*.log'):
    for row in [json.loads(line) for line in path.read_text().splitlines() if line.strip()]:records[json.dumps(row,sort_keys=True)]=row
   assert records and all(row.get('level') in ['debug','info','warn'] for row in records.values())
   clock=[row for row in raw if row['event']['type']=='resource' and row['event']['guest']==guest];offset_min=min(row['event']['sample']['unixMs']-row['unixMs'] for row in clock);offset_max=max(row['event']['sample']['unixMs']-row['event']['hostStartedUnixMs'] for row in clock)
   rejected=[row for row in records.values() if row.get('event')=='connection_rejected' and row['timestampUnixMs']-offset_min>=raw[0]['unixMs']]
   assert all(row['reason']=='outbound' and row['timestampUnixMs']-offset_min>=kill_start and row['timestampUnixMs']-offset_max<=kill_end for row in rejected),rejected
   rejections[guest]=rejected
  run('python3',root/'large-integrity.py',topology,topology+'-large',closure/'fixed-control-v2/payload-4.bin');run('python3',closure/'attest-no-oom.py',root,topology)
  result={'scope':'LOCAL_KVM_CONSTRAINED','topology':topology,'landingVcpus':1,'landingRamMiB':1024,'stress':json.loads((root/(topology+'-stress-audit.json')).read_text()),'recoveryAttempts':len(attempts),'firstRecoverySeconds':recovery_seconds,'restart':kill,'controlledRejections':rejections,'status':'PASS'};results.append(result);(root/(topology+'-constrained-audit.json')).write_text(json.dumps(result,indent=2)+'\n')
 finally:run(driver,'stop',root,topology)
(root/'complete.json').write_text(json.dumps({'scope':'LOCAL_KVM_CONSTRAINED','results':results,'status':'PASS'},indent=2)+'\n');print(json.dumps({'status':'PASS','topologies':len(results)}))
