import pathlib,json,collections,hashlib,sys
root=pathlib.Path(__file__).parent;topology=sys.argv[1];d=root/f'{topology}-faults'
expected_image=hashlib.sha256((root/'inputs/rust-reality').read_bytes()).hexdigest()
rows=[json.loads(l) for l in (d/'events.jsonl').read_text().splitlines()];events=[r['event'] for r in rows]
assert json.loads((d/'complete.json').read_text())['scope']=='LOCAL_KVM'
counts=collections.defaultdict(lambda:collections.Counter());rtts=[];recovery=[]
for r in rows:
 e=r['event']
 if e['type']=='transfer':counts[e['label']]['attempts']+=1;counts[e['label']]['successes']+=e['result']['ok']
 elif e['type']=='rtt':rtts.append(e)
 elif e['type']=='recovery':recovery.append(e)
for k,v in counts.items():
 if k!='partition-counted-outcomes':assert v['attempts']==v['successes'],(k,v)
for k in ['100-consecutive-after-netem','100-consecutive-after-partition','100-consecutive-after-kill']:
 assert counts[k]['attempts']==(400 if k=='100-consecutive-after-netem' else 100)
terminal=json.loads((d/'unaffected-flow/terminal.json').read_text());assert terminal['elapsed']>=30 and terminal['receivedBytes']==terminal['sentBytes'] and terminal['receivedSha256']==terminal['sentSha256']
sent=(d/'unaffected-flow/sent.bin').read_bytes();received=(d/'unaffected-flow/received.bin').read_bytes()
assert sent==received and hashlib.sha256(sent).hexdigest()==terminal['sentSha256']
assert all(e['result']['integrity'] for e in events if e['type'] in ['transfer','readiness'] and e['result']['ok'])
resources={}
for guest in ['line-a','line-b','landing']:
 a=[e['sample'] for e in events if e['type']=='resource' and e['guest']==guest];assert len(a)>=12
 assert len({x['bootId'] for x in a})==1 and {x['imageSha256'] for x in a}=={expected_image}
 first,last=a[0],a[-1];limits={'fds':(256,1024) if guest=='landing' else (768,2048),'threads':(first['threads']+8,first['threads']+16),'rssKiB':(first['rssKiB']+32768,first['rssKiB']+98304)}
 for k,(final,peak) in limits.items():assert last[k]<=final and max(x[k] for x in a)<=peak,(guest,k)
 identities=sorted({(x['pid'],x['starttime']) for x in a});assert len(identities)==(2 if guest=='landing' else 1)
 resources[guest]={'samples':len(a),'identities':identities,'baseline':{k:first[k] for k in limits},'final':{k:last[k] for k in limits},'peak':{k:max(x[k] for x in a) for k in limits}}
# First successful new transfer after recorded restoration/kill, not the end
# of the following 100-success batch. Driver may omit a restoration timestamp
# for netem cells; retain its conservative whole-recovery duration separately.
restored=[]
for i,r in enumerate(rows):
 if r['event']['type'] in ['partition-restored','landing_restart']:
  next_success=next(x for x in rows[i+1:] if x['event']['type']=='readiness' and x['event']['result']['ok'])
  seconds=next_success['elapsed']-r['elapsed'];assert seconds<=43;restored.append({'event':r['event']['type'],'firstNewTransferSeconds':seconds})
rejections={}
partition_start=next(r['unixMs'] for r in rows if r['event']['type']=='partition-start')
partition_end=next(r['unixMs'] for r in rows if r['event']['type']=='partition-restored')+43000
kill_start=min(r['unixMs'] for r in rows if r['event']['type']=='resource' and r['event']['label']=='before-landing-kill')
kill_end=next(r['unixMs'] for r in rows if r['event']['type']=='landing_restart')+43000
for guest in resources:
 clock=[r for r in rows if r['event']['type']=='resource' and r['event']['guest']==guest]
 offset_min=min(r['event']['sample']['unixMs']-r['unixMs'] for r in clock)
 offset_max=max(r['event']['sample']['unixMs']-r['event']['hostStartedUnixMs'] for r in clock)
 logs={}
 for f in d.glob(f'{guest}-server-*.log'):
  parsed=[json.loads(l) for l in f.read_text().splitlines() if l.strip()]
  assert parsed and all(e.get('level') in ['debug','info','warn'] for e in parsed),(guest,'unexpected/error log record')
  start=parsed[0]['timestampUnixMs']
  if start not in logs or len(parsed)>len(logs[start]):logs[start]=parsed
 rejected=[{k:v for k,v in e.items() if k!='peer'} for log in logs.values() for e in log if e.get('event')=='connection_rejected' and e['timestampUnixMs']-offset_min>=rows[0]['unixMs']]
 assert all(e['reason']=='outbound' for e in rejected),rejected
 windows=[(kill_start,kill_end)]+([(partition_start,partition_end)] if guest=='line-a' else [])
 assert all(any(e['timestampUnixMs']-offset_min>=lo and e['timestampUnixMs']-offset_max<=hi for lo,hi in windows) for e in rejected),rejected
 rejections[guest]=rejected
result={'scope':'LOCAL_KVM','sourceCommit':json.loads((root/'scope.json').read_text())['sourceCommit'],'topology':topology,'counts':counts,'rttMeasurements':rtts,'wholeNetemRecoveryIncluding100Transfers':recovery,'firstRecovery':restored,'unaffectedFlow':terminal,'resources':resources,'controlledFaultRejections':rejections,'maxRecordedTransferSeconds':max(e['result']['seconds'] for e in events if e['type'] in ['transfer','readiness']),'status':'PASS'}
(root/f'{topology}-faults-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
