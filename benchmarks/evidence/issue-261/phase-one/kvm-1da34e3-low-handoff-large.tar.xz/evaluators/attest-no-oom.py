import json,pathlib,subprocess,sys
root=pathlib.Path(sys.argv[1]);label=sys.argv[2];attestation=json.loads((root/'provision-attestation.json').read_text());result={'scope':'LOCAL_KVM','label':label,'guests':{}}
for guest in ['landing','line-a','line-b']:
 raw=subprocess.check_output(['ssh','-F',str(root/'ssh-config'),guest,'cat /proc/sys/kernel/random/boot_id; cat /proc/vmstat'],text=True);lines=raw.splitlines();stats={key:int(value) for key,value in (line.split() for line in lines[1:])}
 assert lines[0]==attestation['guests'][guest]['guestReceipt'].splitlines()[1]
 assert stats['oom_kill']==0,(guest,stats['oom_kill'])
 result['guests'][guest]={'bootId':lines[0],'oomKillsSinceBoot':stats['oom_kill'],'vmstat':stats}
with (root/(label+'-oom-audit.json')).open('x') as handle:handle.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({guest:values['oomKillsSinceBoot'] for guest,values in result['guests'].items()}))
