import hashlib,json,pathlib
root=pathlib.Path('/home/jacek/.cache/rr-phase1-kvm/candidate-1da34e3');result={'scope':'LOCAL_KVM','sourceCommit':'1da34e37a2b38a774eb3fc14764c108356606963','topologies':{}}
for topology in ['handoff','nxr']:
 roles={}
 for guest in ['line-a','line-b']:
  path=max((root/(topology+'-lifecycle')).glob(guest+'-server-*.log'),key=lambda path:path.stat().st_size);rows=[json.loads(line) for line in path.read_text().splitlines() if line.strip()]
  summaries=[row for row in rows if row.get('event')=='transport_pool_summary' and row['transport']==topology];assert len(summaries)==1;summary=summaries[0];assert summary['generation']==0
  for key in ['pool_checkout_hit','pool_cold_fallback','pool_stale_discard']:assert summary[key]>0
  publish=[row for row in rows if row.get('event')=='configuration_published'];assert [row['generation'] for row in publish]==[0,1]
  after=[row for row in rows if row['timestampUnixMs']>publish[-1]['timestampUnixMs'] and row.get('event')=='connection_completed'];assert after
  roles[guest]={'logSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'generationZeroSummary':summary,'publication':publish,'completedConnectionsAfterPublication':len(after)}
 result['topologies'][topology]=roles
result['status']='PASS: warm/stale/cold counters and new-generation publication followed by completed admissions; speculative-resource retirement is additionally covered by exact-source unit tests'
(root/'warm-lifecycle-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
