import collections,hashlib,json,pathlib,sys
root=pathlib.Path(__file__).parent;topology=sys.argv[1];out=root/f'{topology}-stress'
expected=hashlib.file_digest(open(root/'inputs/rust-reality','rb'),'sha256').hexdigest()
ports={json.loads((root/'guests.json').read_text())[guest]['socksPort'] for guest in ['line-a','line-b']};assert len(ports)==2
rows=[json.loads(line) for line in (out/'events.jsonl').read_text().splitlines()];events=[row['event'] for row in rows]
complete=json.loads((out/'complete.json').read_text());assert complete['scope']=='LOCAL_KVM' and complete['cycles']==8 and complete['transfersPerLinePerCycle']==100
cycles=[e for e in events if e['type']=='cycle'];assert [e['index'] for e in cycles]==list(range(8))
assert {e['concurrency'] for e in cycles}=={8,32} and all(e['transfersPerLine']==100 for e in cycles)
assert not any(e['type'] in ['landing_restart','reload'] for e in events),'stress must not reset process or generation state'
counts=collections.defaultdict(collections.Counter);attempts=[];uploads=[]
for e in events:
 if e['type']=='transfer':counts[e['label']][e['result']['port']]+=1;attempts.append(e['result'])
 elif e['type']=='readiness':attempts.append(e['result'])
 elif e['type']=='bidirectional':attempts.extend([e['upload'],e['download']]);uploads.append(e['upload'])
assert set(counts)=={f'cycle-{i}' for i in range(8)}
for label,count in counts.items():assert dict(count)=={p:100 for p in ports},(label,count)
for attempt in attempts:
 assert attempt['ok'] and attempt['code']==0 and attempt['integrity'],attempt
 assert 0<=attempt['seconds']<=43,attempt
 if not attempt['upload']:assert attempt['bytes']==1048576 and attempt['sha256']=='fbbab289f7f94b25736c58be46a994c441fd02552cc6022352e3d86d2fab7c83'
assert len(uploads)==2 and {a['port'] for a in uploads}==ports
receipts=[json.loads(line) for line in (out/'upload-receipts.jsonl').read_text().splitlines()]
for upload in uploads:
 path=f'/upload/{topology}-stress/{upload["id"]}'
 matches=[r for r in receipts if r['method']=='PUT' and r['path']==path]
 assert len(matches)==1 and matches[0]['bytes']==1048576 and matches[0]['sha256']=='fbbab289f7f94b25736c58be46a994c441fd02552cc6022352e3d86d2fab7c83'
resources={};boots=set()
for guest in ['line-a','line-b','landing']:
 entries=[e for e in events if e['type']=='resource' and e['guest']==guest];samples=[e['sample'] for e in entries]
 assert len(samples)>=18
 identities={(s['pid'],s['starttime'],s['bootId'],s['imageSha256']) for s in samples};assert len(identities)==1 and samples[0]['imageSha256']==expected
 boots.add(samples[0]['bootId']);baseline=samples[0]
 for sample in samples:
  for field in ['pid','fds','threads','rssKiB','pssKiB','anonymousKiB','privateDirtyKiB','closedDuringSample']:
   assert type(sample[field]) is int and sample[field]>=0,(guest,field,sample[field])
  assert sample['pid']>1 and sample['threads']>0 and sample['rssKiB']>0
  assert sample['fds']==len(sample['fdTargets'])
 recovered=[]
 for cycle in range(8):
  matching=[e['sample'] for e in entries if e['label']==f'cycle-{cycle}-recovered'];assert len(matching)==1
  recovered.append(matching[0])
 limits={'fds':(256,1024) if guest=='landing' else (768,2048),'threads':(baseline['threads']+8,baseline['threads']+16),'rssKiB':(baseline['rssKiB']+32768,baseline['rssKiB']+98304)}
 for field,(final,peak) in limits.items():
  assert max(s[field] for s in samples)<=peak,(guest,field,'peak')
  assert all(s[field]<=final for s in [*recovered,samples[-1]]),(guest,field,'recovery')
 logfiles=list(out.glob(guest+'-server-*.log'));assert logfiles
 rejects=[]
 for logfile in logfiles:
  records=[json.loads(line) for line in logfile.read_text().splitlines() if line.strip()]
  assert records and all(r.get('level') in ['debug','info','warn'] for r in records),(guest,'unexpected/error log record')
  rejects.extend(r for r in records if r.get('event')=='connection_rejected')
 assert not rejects,(guest,rejects)
 fields=['fds','threads','rssKiB','pssKiB','anonymousKiB','privateDirtyKiB']
 resources[guest]={'identity':list(next(iter(identities))),'sampleCount':len(samples),'baseline':{k:baseline[k] for k in fields},'peak':{k:max(s[k] for s in samples) for k in fields},'recovered':[{k:s[k] for k in fields} for s in recovered],'lastFourRecoveredRange':{k:max(s[k] for s in recovered[-4:])-min(s[k] for s in recovered[-4:]) for k in fields},'final':{k:samples[-1][k] for k in fields},'closedDuringSampling':sum(s['closedDuringSample'] for s in samples)}
assert len(boots)==3
result={'scope':'LOCAL_KVM','sourceCommit':json.loads((root/'scope.json').read_text())['sourceCommit'],'topology':topology,'status':'PASS','claim':'finite-work integrity, no-restart identity and reviewed resource envelopes; no elapsed-month equivalence','cycles':cycles,'countsByLinePort':{k:dict(v) for k,v in counts.items()},'verifiedAttempts':len(attempts),'resources':resources,'maxTransferSeconds':max(a['seconds'] for a in attempts)}
(root/f'{topology}-stress-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
