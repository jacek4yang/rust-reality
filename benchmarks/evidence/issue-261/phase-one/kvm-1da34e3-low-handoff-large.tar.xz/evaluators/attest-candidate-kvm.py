import hashlib,json,pathlib,socket,subprocess,sys
root=pathlib.Path(sys.argv[1]);provision=pathlib.Path(sys.argv[2]);base=pathlib.Path('/home/jacek/.cache/rr-phase1-kvm/qualification-20261007')
image=hashlib.file_digest(open(base/'noble-server-cloudimg-amd64.img','rb'),'sha256').hexdigest();assert image=='6a81c37564db9b1ee84e141922625e1d7c5b389b99bb3c572e0243607d5bb4d2'
specs=json.loads((root/'guests.json').read_text());result={'scope':'LOCAL_KVM','imageSha256':image,'guests':{}}
for guest in ['landing','line-a','line-b']:
 spec=specs[guest]
 with socket.socket(socket.AF_UNIX) as sock:
  sock.settimeout(5);sock.connect(str(provision/guest/'qmp.sock'));stream=sock.makefile('rwb');greeting=json.loads(stream.readline())
  def query(command):
   stream.write(json.dumps({'execute':command}).encode()+b'\n');stream.flush()
   while True:
    row=json.loads(stream.readline())
    if 'return' in row:return row['return']
    if 'error' in row:raise RuntimeError(row)
  query('qmp_capabilities');kvm=query('query-kvm');cpus=query('query-cpus-fast');memory=query('query-memory-size-summary')
  assert kvm['enabled'] and len(cpus)==spec['cpus'] and memory['base-memory']==spec['ramMiB']*1048576
 receipt=subprocess.check_output(['ssh','-F',str(root/'ssh-config'),guest,'uname -smr; cat /proc/sys/kernel/random/boot_id; nproc; cat /proc/meminfo; ldd --version; ip -br address; ulimit -n; tc -V'],text=True)
 assert int(receipt.splitlines()[2])==spec['cpus']
 pid=int((provision/guest/'pid').read_text());cmdline=pathlib.Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
 assert b'qemu-system-x86_64' in cmdline[0]
 bindings=[line for line in subprocess.check_output(['ss','-ltnp'],text=True).splitlines() if f'pid={pid},' in line]
 assert bindings and all(line.split()[3].startswith('127.0.0.1:') for line in bindings)
 result['guests'][guest]={'kvm':kvm,'qemuVersion':greeting['QMP']['version'],'cpus':len(cpus),'memory':memory,'hostAffinity':pathlib.Path(f'/proc/{pid}/status').read_text().split('Cpus_allowed_list:')[1].splitlines()[0].strip(),'loopbackOnlyBindings':True,'guestReceipt':receipt}
assert len({entry['guestReceipt'].splitlines()[1] for entry in result['guests'].values()})==3
with (root/'provision-attestation.json').open('x') as out:out.write(json.dumps(result,indent=2)+'\n')
print(json.dumps({name:{key:value[key] for key in ['kvm','cpus','memory','hostAffinity','loopbackOnlyBindings']} for name,value in result['guests'].items()},indent=2))
