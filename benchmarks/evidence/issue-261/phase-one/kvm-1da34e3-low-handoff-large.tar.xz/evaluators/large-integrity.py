import pathlib,sys,json,hashlib,subprocess,concurrent.futures,time
root=pathlib.Path(__file__).parent;topology=sys.argv[1];label=sys.argv[2];payload=pathlib.Path(sys.argv[3]);out=root/label;out.mkdir()
with payload.open('rb') as f:expected=hashlib.file_digest(f,'sha256').hexdigest()
assert payload.stat().st_size==4194304
spec=json.loads((root/'guests.json').read_text());directory=f'/home/rrtest/qualification/candidate-1da34e3/{topology}'
def access():return subprocess.check_output(['ssh','-F',str(root/'ssh-config'),'landing',f'cat {directory}/access.jsonl'])
before=access();results=[];uploads=[]
for guest in ['line-a','line-b']:
 port=spec[guest]['socksPort'];path=f'/upload/{label}/{guest}/{time.monotonic_ns()}';uploads.append(path)
 def transfer(upload):
  output=out/f'{guest}-{"upload-response" if upload else "download"}.bin'
  command=['curl','--fail','--silent','--show-error','--max-time','43','--noproxy','','--socks5-hostname',f'127.0.0.1:{port}','--output',str(output)]
  if upload:command+=['--upload-file',str(payload),f'http://127.0.0.1:8080{path}']
  else:command+=['http://127.0.0.1:8080/payload-4.bin']
  start=time.monotonic();p=subprocess.run(command,capture_output=True);receipt={'guest':guest,'upload':upload,'exit':p.returncode,'seconds':time.monotonic()-start,'stderr':p.stderr.decode(),'path':path if upload else '/payload-4.bin'}
  assert p.returncode==0,receipt
  if not upload:
   with output.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
   assert output.stat().st_size==4194304 and digest==expected
   receipt.update(bytes=4194304,sha256=digest)
  return receipt
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  futures=[pool.submit(transfer,x) for x in [False,True]];results.extend(f.result() for f in futures)
after=access();assert after.startswith(before);new=after[len(before):];rows=[json.loads(l) for l in new.splitlines() if l]
for path in uploads:
 matches=[r for r in rows if r['method']=='PUT' and r['path']==path]
 assert len(matches)==1 and matches[0]['bytes']==4194304 and matches[0]['sha256']==expected,matches
(out/'new-access-rows.jsonl').write_bytes(new)
result={'scope':'LOCAL_KVM','topology':topology,'bytesPerTransfer':4194304,'payloadSha256':expected,'results':results,'uploadReceipts':[r for r in rows if r['path'] in uploads],'status':'PASS'}
(out/'complete.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
