import pathlib,json,lzma,hashlib,re,xml.etree.ElementTree as ET
root=pathlib.Path('/home/jacek/Projects/rust-reality/benchmarks/evidence/issue-261/pinned-profile')
manifest=json.loads((root/'manifest.json').read_text());listed={f['path']:f for f in manifest['files']};inputs={}
def load(name):
 raw=(root/name).read_bytes();item=listed[name];assert hashlib.sha256(raw).hexdigest()==item['sha256']
 data=lzma.decompress(raw) if name.endswith('.xz') else raw
 assert hashlib.sha256(data).hexdigest()==item['original_sha256'];inputs[name]=item['sha256'];return data
result={'scope':'historical-profile-allocation-origin-ledger-not-current-candidate-proof','evidenceCommit':'baa1a9fc3bdc0037957a3a376d9e3cdbdcc11a5b','source':manifest['product_source'],'binary':manifest['product_sha256'],'note':'Only the five previously ownership-validated traces are used. Standalone trace remains rejected. Requested live allocation and malloc_info non-free totals are different metrics; profiler/observer overhead remains included. Each clock is relative to its own first snapshot, not the native acceptance clock. No exit-free result is used as proof.','roles':{}}
for role in ['handoff-landing','handoff-line','nxr-landing','nxr-line','socks-line']:
 owners=json.loads(load(f'attribution/{role}.owners.json.xz'));timeline=json.loads(load(f'attribution/{role}.timeline.json.xz'))
 selected=[]
 for target in [30,880,1780]:
  row=max((x for x in owners['trajectory'] if x['seconds']<=target),key=lambda x:x['seconds'])
  selected.append({'targetSeconds':target,'seconds':row['seconds'],'liveRequestedBytes':sum(row['live_bytes'].values()),'liveAllocationCount':row['live_allocation_count'],'allocationOriginBytes':row['live_bytes']})
 raw=load(f'traces/soak-{role}.malloc-info.xz').decode();alloc=[]
 for m in re.finditer(r'<!-- pid=(\d+) monotonic_seconds=([\d.]+) -->\s*(<malloc.*?</malloc>)',raw,re.S):
  tree=ET.fromstring(m[3]);totals={x.attrib['type']:int(x.attrib['size']) for x in tree.findall('total')};system={x.attrib['type']:int(x.attrib['size']) for x in tree.findall('system')};free=totals.get('fast',0)+totals.get('rest',0)
  alloc.append({'monotonicSeconds':float(m[2]),'arenaCount':len(tree.findall('heap')),'systemBytes':system['current'],'freeBytes':free,'mmapBytes':totals.get('mmap',0),'nonFreeUpperBoundBytes':system['current']-free+totals.get('mmap',0)})
 origin=alloc[0]['monotonicSeconds'];selected_alloc=[]
 for target in [30,880,1780]:
  row=min(alloc,key=lambda x:abs(x['monotonicSeconds']-origin-target));selected_alloc.append(dict(targetSeconds=target,relativeSeconds=row['monotonicSeconds']-origin,**row))
 keys=['systemBytes','freeBytes','mmapBytes','nonFreeUpperBoundBytes'];delta={k:selected_alloc[-1][k]-selected_alloc[1][k] for k in keys}
 result['roles'][role]={'liveSnapshots':selected,'allocatorSnapshots':selected_alloc,'lateAllocatorDelta':delta,'lateLiveRequestedDelta':selected[-1]['liveRequestedBytes']-selected[1]['liveRequestedBytes']}
result['inputSha256']=inputs
out=pathlib.Path(__file__).parent/'historical-owner-ledger.json';out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({role:{'lateLiveRequestedDelta':v['lateLiveRequestedDelta'],'lateAllocatorDelta':v['lateAllocatorDelta']} for role,v in result['roles'].items()},indent=2))
