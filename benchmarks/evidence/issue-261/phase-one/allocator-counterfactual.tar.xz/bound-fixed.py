import pathlib,json,math,hashlib
root=pathlib.Path(__file__).parent;out={'scope':'finite-workload-upper-bounds-not-universal-retention-bound','formula':'For K accepted TCP connections per process and at most one nonce reservation per connection: sum of hash buckets <=64+ceil(16*K/7); sum of REALITY heap slots <=64+4*K (reserve plus commit); sum of landing nonce heap slots <=64+2*K. Includes growth/tombstones conservatively via cumulative insertion count, not uniform-shard assumptions. Excludes cache construction and transient resize overlap. This bounds retained requested cache allocation attributable to this finite workload, not allocator residency.','runs':{}}
for run in ['fixed-control-v2','fixed-observer-v2']:
 out['runs'][run]={}
 for role in ['handoff-landing','handoff-line','nxr-landing','nxr-line','socks-line','standalone']:
  p=root/run/f'{role}.log';raw=p.read_bytes();events=[json.loads(l) for l in raw.splitlines() if l.startswith(b'{')]
  k=sum(x.get('event')=='connection_accepted' for x in events);assert k>=400,(role,k)
  buckets=64+math.ceil(16*k/7)
  reality=97*buckets+16*16+56*(64+4*k)
  nonce=33*buckets+16*16+32*(64+2*k)
  out['runs'][run][role]={'acceptedTcpConnections':k,'logSha256':hashlib.sha256(raw).hexdigest(),'realityCacheRetainedGrowthUpperBoundBytes':reality,'landingNonceCacheRetainedGrowthUpperBoundBytes':nonce if role.endswith('landing') else 0,'rejections':sum(x.get('event')=='connection_rejected' for x in events)}
(root/'finite-workload-cache-bounds.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
