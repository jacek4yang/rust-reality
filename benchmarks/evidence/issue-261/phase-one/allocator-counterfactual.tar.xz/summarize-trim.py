import pathlib,json,re,sys
r=pathlib.Path(__file__).parent;name=sys.argv[1];a=json.loads((r/f'{name}-analysis.json').read_text());result={'scope':'diagnostic-only-counterfactual-not-production-policy','run':name,'complete':a['complete'],'roles':{}}
assert a['complete']['failures']==0
for role,v in a['roles'].items():
 before=next(s for s in v['samples'] if s['label']=='before-diagnostic-trim');after=next(s for s in v['samples'] if s['label']=='after-diagnostic-trim')
 for k in ['pid','starttime','fds','threads']:assert before[k]==after[k],(role,k)
 markers=re.findall(r'diagnostic_malloc_trim pid=(\d+) monotonic_seconds=([\d.]+) returned=(\d+)',(r/name/f'{role}.malloc-info').read_text());assert len(markers)==1
 pid,t,returned=markers[0];assert int(pid)==before['pid'];t=float(t)
 allocator_before=max((x for x in v['allocator'] if x['monotonicSeconds']<t),key=lambda x:x['monotonicSeconds'])
 allocator_after=min((x for x in v['allocator'] if x['monotonicSeconds']>=t),key=lambda x:x['monotonicSeconds'])
 result['roles'][role]={'before':before,'after':after,'releasedAnonymousKiB':before['Anonymous']-after['Anonymous'],'releasedPssKiB':before['Pss']-after['Pss'],'trimReturned':int(returned),'allocatorBefore':allocator_before,'allocatorAfter':allocator_after,'allocatorDelta':{k:allocator_after[k]-allocator_before[k] for k in ['systemBytes','freeBytes','mmapBytes','nonFreeUpperBoundBytes','arenas']}}
(r/f'{name}-trim-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({role:{k:v[k] for k in ['releasedAnonymousKiB','releasedPssKiB','trimReturned','allocatorDelta']} for role,v in result['roles'].items()},indent=2))
