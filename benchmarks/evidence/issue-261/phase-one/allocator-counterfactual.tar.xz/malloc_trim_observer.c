#define _GNU_SOURCE
#include <errno.h>
#include <malloc.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

/* Diagnostic counterfactual only: SIGUSR2 requests one malloc_trim(0).
 * No allocation interposition or allocator tuning. Never a production fix. */
static FILE *output;
static volatile sig_atomic_t trim_requested;
static void request_trim(int signal) { (void)signal; trim_requested = 1; }
static void *observe(void *unused) {
    (void)unused;
    for (;;) {
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        if (trim_requested) {
            trim_requested = 0;
            int result = malloc_trim(0);
            fprintf(output, "<!-- diagnostic_malloc_trim pid=%ld monotonic_seconds=%ld.%09ld returned=%d -->\n",
                    (long)getpid(), (long)now.tv_sec, now.tv_nsec, result);
        }
        fprintf(output, "<!-- pid=%ld monotonic_seconds=%ld.%09ld -->\n",
                (long)getpid(), (long)now.tv_sec, now.tv_nsec);
        if (malloc_info(0, output) != 0) {
            fprintf(output, "<!-- malloc_info_error=%d -->\n", errno);
        }
        fflush(output);
        struct timespec interval = {.tv_sec = 10, .tv_nsec = 0};
        while (nanosleep(&interval, &interval) < 0 && errno == EINTR) {}
    }
    return NULL;
}
__attribute__((constructor)) static void start_observer(void) {
    const char *path = getenv("RR_261_MALLOC_INFO");
    if (!path) return;
    output = fopen(path, "wx");
    if (!output) { perror("diagnostic malloc_info fopen"); _exit(121); }
    struct sigaction action = {0};
    action.sa_handler = request_trim;
    fprintf(output, "<!-- diagnostic_trim_observer=1 -->\n");
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGUSR2, &action, NULL)) { perror("sigaction"); _exit(123); }
    pthread_t worker;
    int error = pthread_create(&worker, NULL, observe, NULL);
    if (error) { fprintf(stderr, "pthread_create: %d\n", error); _exit(122); }
    pthread_detach(worker);
}
