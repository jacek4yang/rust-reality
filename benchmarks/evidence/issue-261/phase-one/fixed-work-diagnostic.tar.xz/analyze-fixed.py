import json,pathlib,re,xml.etree.ElementTree as ET,sys
r=pathlib.Path(__file__).parent
for name in sys.argv[1:]:
 d=r/name;rows=[json.loads(l) for l in (d/'fixed-work.jsonl').read_text().splitlines()]
 roles={}
 for role in rows[0]['processes']:
  vals=[]
  for row in rows:
   p=row['processes'][role];text=(d/f'{row["label"]}-{role}-smaps').read_text(); fields={}
   for line in text.splitlines():
    m=re.match(r'(Pss|Anonymous|Private_Dirty|Rss|Size|Swap):\s+(\d+)',line)
    if m:fields[m[1]]=fields.get(m[1],0)+int(m[2])
   vals.append(dict(label=row['label'],seconds=row['monotonicSeconds'],pid=p['pid'],starttime=p['pidStarttime'],fds=p['fds'],threads=p['threads'],**fields))
  xml=d/f'{role}.malloc-info';alloc=[]
  if xml.exists():
   raw=xml.read_text()
   for match in re.finditer(r'<!-- pid=(\d+) monotonic_seconds=([\d.]+) -->\s*(<malloc.*?</malloc>)',raw,re.S):
    tree=ET.fromstring(match[3]); totals={x.attrib['type']:int(x.attrib['size']) for x in tree.findall('total')}; system={x.attrib['type']:int(x.attrib['size']) for x in tree.findall('system')}
    free=totals.get('fast',0)+totals.get('rest',0)
    alloc.append(dict(pid=int(match[1]),monotonicSeconds=float(match[2]),arenas=len(tree.findall('heap')),systemBytes=system['current'],freeBytes=free,mmapBytes=totals.get('mmap',0),nonFreeUpperBoundBytes=system['current']-free+totals.get('mmap',0)))
  roles[role]={'samples':vals,'allocator':alloc}
  print(name,role,'baseline',vals[0],'last',vals[-1], 'allocatorFirstLast',alloc[:1]+alloc[-1:])
 (r/f'{name}-analysis.json').write_text(json.dumps({'scope':'diagnostic-not-qualification','roles':roles,'complete':json.loads((d/'fixed-work-complete.json').read_text()) if (d/'fixed-work-complete.json').exists() else None},indent=2)+'\n')
