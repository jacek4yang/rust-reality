#define _GNU_SOURCE
#include <errno.h>
#include <malloc.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

/* Diagnostic preload only. Reads allocator state; changes no allocator knobs. */
static FILE *output;
static void *observe(void *unused) {
    (void)unused;
    for (;;) {
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        fprintf(output, "<!-- pid=%ld monotonic_seconds=%ld.%09ld -->\n",
                (long)getpid(), (long)now.tv_sec, now.tv_nsec);
        if (malloc_info(0, output) != 0) {
            fprintf(output, "<!-- malloc_info_error=%d -->\n", errno);
        }
        fflush(output);
        struct timespec interval = {.tv_sec = 10, .tv_nsec = 0};
        while (nanosleep(&interval, &interval) < 0 && errno == EINTR) {}
    }
    return NULL;
}

__attribute__((constructor)) static void start_observer(void) {
    const char *path = getenv("RR_261_MALLOC_INFO");
    if (!path) return;
    output = fopen(path, "wx");
    if (!output) {
        perror("diagnostic malloc_info fopen");
        _exit(121);
    }
    pthread_t worker;
    int error = pthread_create(&worker, NULL, observe, NULL);
    if (error) {
        fprintf(stderr, "diagnostic malloc_info pthread_create: %d\n", error);
        _exit(122);
    }
    pthread_detach(worker);
}
