import array,collections,fcntl,json,os,pathlib,sys,termios
pid=int(sys.argv[1]);proc=pathlib.Path('/proc')/str(pid);before=(proc/'stat').read_text().rsplit(')',1)[1].split()[19];counts=collections.Counter();pipes=[]
for item in (proc/'fd').iterdir():
 try:target=os.readlink(item)
 except FileNotFoundError:continue
 counts[target.split(':')[0]]+=1
 if target.startswith('pipe:['):
  fd=os.open(item,os.O_RDONLY|os.O_NONBLOCK)
  try:
   pending=array.array('i',[0]);fcntl.ioctl(fd,termios.FIONREAD,pending,True);pipes.append({'fd':int(item.name),'target':target,'pendingBytes':pending[0]})
  finally:os.close(fd)
assert before==(proc/'stat').read_text().rsplit(')',1)[1].split()[19]
print(json.dumps({'pid':pid,'starttime':before,'bootId':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'descriptorKinds':dict(counts),'pipeDescriptors':len(pipes),'uniquePipes':len({p['target'] for p in pipes}),'pendingBytesSumAcrossEnds':sum(p['pendingBytes'] for p in pipes),'pipes':pipes}))
