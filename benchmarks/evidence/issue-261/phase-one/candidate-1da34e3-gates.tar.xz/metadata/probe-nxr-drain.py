import json,pathlib,subprocess,time
root=pathlib.Path('/home/jacek/.cache/rr-phase1-kvm/candidate-1da34e3');out=root/'nxr-drain-discriminator-v2';out.mkdir();driver='/home/jacek/.cache/rr-phase1-kvm/qualification-20261007/driver/target/release/rr-local-kvm-diagnostic';rows=[]
def sample(label):
 raw=subprocess.check_output(['ssh','-F',str(root/'ssh-config'),'landing','/home/rrtest/bin/vm-driver sample /home/rrtest/qualification/candidate-1da34e3/nxr && ss -tanp'],text=True)
 line,network=raw.split('\n',1);row={'elapsed':time.monotonic()-start,'label':label,'sample':json.loads(line),'sockets':network};rows.append(row)
 with (out/'samples.jsonl').open('a') as handle:handle.write(json.dumps(row)+'\n')
start=time.monotonic();sample('before')
subprocess.run([driver,'smoke',str(root),'nxr','nxr-drain-load'],check=True);sample('load-finished');finish=time.monotonic()
for index in range(46):
 time.sleep(max(0,finish+index-time.monotonic()));sample('quiet-'+str(index))
result={'scope':'LOCAL_KVM','workload':'100 normal transfers plus bidirectional integrity, no daemon restart','fdTimeline':[{'seconds':round(r['elapsed'],3),'fds':r['sample']['fds'],'pid':r['sample']['pid']} for r in rows]}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
