import copy,json,os,pathlib,shutil,subprocess,tempfile
source=pathlib.Path('/home/jacek/.cache/rr-phase1-kvm/candidate-1da34e3');records=[]
for case in ['valid','missing-transfer','changed-pid','wrong-download-hash','fd-recovery-over-cap','plain-panic-log','duplicate-upload-receipt','wrong-image']:
 with tempfile.TemporaryDirectory(prefix='rr-stress-audit-') as temporary:
  root=pathlib.Path(temporary);(root/'inputs').mkdir();shutil.copyfile(source/'inputs/rust-reality',root/'inputs/rust-reality')
  for name in ['audit-stress.py','guests.json','scope.json']:shutil.copyfile(source/name,root/name)
  shutil.copytree(source/'handoff-stress',root/'handoff-stress');data=root/'handoff-stress';events_path=data/'events.jsonl'
  rows=[json.loads(line) for line in events_path.read_text().splitlines()]
  if case=='missing-transfer':rows.remove(next(row for row in rows if row['event']['type']=='transfer'))
  elif case=='changed-pid':next(row['event']['sample'] for row in rows if row['event']['type']=='resource')['pid']+=1
  elif case=='wrong-download-hash':next(row['event']['result'] for row in rows if row['event']['type']=='transfer')['sha256']='0'*64
  elif case=='fd-recovery-over-cap':
   sample=next(row['event']['sample'] for row in rows if row['event']['type']=='resource' and row['event']['guest']=='line-a' and row['event']['label']=='cycle-0-recovered')
   sample['fds']=769;sample['fdTargets']=['pipe:[synthetic-boundary-fixture]']*769
  elif case=='plain-panic-log':
   log=next(data.glob('line-a-server-*.log'))
   with log.open('a') as handle:handle.write('thread runtime panicked: injected negative audit fixture\n')
  elif case=='duplicate-upload-receipt':
   path=data/'upload-receipts.jsonl';entries=path.read_text().splitlines();put=next(line for line in entries if json.loads(line)['method']=='PUT')
   path.write_text('\n'.join([*entries,put])+'\n')
  elif case=='wrong-image':next(row['event']['sample'] for row in rows if row['event']['type']=='resource')['imageSha256']='0'*64
  events_path.write_text(''.join(json.dumps(row)+'\n' for row in rows))
  result=subprocess.run(['python3',str(root/'audit-stress.py'),'handoff'],capture_output=True,text=True)
  assert (result.returncode==0)==(case=='valid'),(case,result.returncode,result.stdout,result.stderr)
  records.append({'case':case,'exitCode':result.returncode,'expected':'accept' if case=='valid' else 'reject'})
output=pathlib.Path('/home/jacek/.cache/rr-phase1-closure/stress-auditor-validation.json');output.write_text(json.dumps({'status':'PASS','cases':records},indent=2)+'\n');print(output.read_text())
